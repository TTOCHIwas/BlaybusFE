export { StudyTimeGrid } from './ui/StudyTimeGrid';
export { 
  logsToGridState, 
  calculateTotalMinutes, 
  formatMinutes,
  isoToSlotIndex 
} from './model/studyTimeUtils';