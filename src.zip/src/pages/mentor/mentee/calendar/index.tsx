import { MentorMenteeCalendarPage } from './MentorMenteeCalendarPage';

export default MentorMenteeCalendarPage;