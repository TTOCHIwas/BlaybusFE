import { Box, Heading } from '@chakra-ui/react';

const MentorTaskCreatePage = () => {
  return (
    <Box p={5}>
      <Heading size="lg" mb={4}>할 일(과제) 등록</Heading>
    </Box>
  );
};

export default MentorTaskCreatePage;