import MentorTaskDetailPage from './MentorTaskDetailPage';

export default MentorTaskDetailPage;