import { Box, Heading, Text } from '@chakra-ui/react';

const MenteePlannerPage = () => {
  return (
    <Box p={5}>
      <Heading size="lg" mb={4}>일일 플래너 (멘티 메인)</Heading>
    </Box>
  );
};

export default MenteePlannerPage;