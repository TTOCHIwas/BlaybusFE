import { Box, Heading } from '@chakra-ui/react';

const MenteeMyPage = () => {
  return (
    <Box p={5}>
      <Heading size="lg" mb={4}>마이페이지</Heading>
    </Box>
  );
};

export default MenteeMyPage;