import { useState } from 'react';
import { Box, Flex, IconButton, Image, Text } from '@chakra-ui/react';
import { ChevronLeftIcon, ChevronRightIcon } from '@chakra-ui/icons';

import { FeedbackOverlay } from '@/features/task-feedback/ui/FeedbackOverlay';
import { UserRole } from '@/shared/constants/enums';

export interface SubmissionImageData {
  id: string;
  imageUrl: string;
}

interface ImageSliderProps {
  images: SubmissionImageData[];
  taskId: string;
  currentUserId: string;
  userRole: UserRole; 
}

export const ImageSlider = ({ images, taskId, currentUserId, userRole }: ImageSliderProps) => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev === 0 ? images.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === images.length - 1 ? 0 : prev + 1));
  };

  if (!images || images.length === 0) {
    return (
      <Box h="400px" bg="gray.100" borderRadius="xl" display="flex" alignItems="center" justifyContent="center">
        <Text color="gray.400">이미지가 없습니다.</Text>
      </Box>
    );
  }

  return (
    <Box position="relative" w="full" bg="gray.900" borderRadius="xl" overflow="hidden" boxShadow="lg">
      <Box position="relative" w="full" h="600px" bg="black">
        <Image
          src={images[currentIndex].imageUrl}
          alt={`Submission ${currentIndex + 1}`}
          w="full"
          h="full"
          objectFit="contain"
        />

        {/* 피드백 오버레이: 상위에서 받은 userRole을 그대로 전달 */}
        <FeedbackOverlay 
          taskId={taskId}
          imageId={images[currentIndex].id}
          currentUserId={currentUserId}
          userRole={userRole} 
        />
      </Box>

      {/* 네비게이션 버튼 (이미지가 1개 이상일 때만) */}
      {images.length > 1 && (
        <>
          <IconButton
            aria-label="Previous image"
            icon={<ChevronLeftIcon boxSize={8} />}
            position="absolute"
            left={4}
            top="50%"
            transform="translateY(-50%)"
            onClick={handlePrev}
            variant="ghost"
            color="white"
            _hover={{ bg: 'whiteAlpha.200' }}
            isRound
            size="lg"
            zIndex={5} // 오버레이보다 위에 있어야 함
          />
          <IconButton
            aria-label="Next image"
            icon={<ChevronRightIcon boxSize={8} />}
            position="absolute"
            right={4}
            top="50%"
            transform="translateY(-50%)"
            onClick={handleNext}
            variant="ghost"
            color="white"
            _hover={{ bg: 'whiteAlpha.200' }}
            isRound
            size="lg"
            zIndex={5}
          />
        </>
      )}

      <Flex 
        position="absolute" 
        bottom={4} 
        left={0} 
        right={0} 
        justify="center" 
        align="center"
        px={6}
        pointerEvents="none" 
      >
        <Box bg="blackAlpha.600" px={3} py={1} borderRadius="full" pointerEvents="auto">
          <Text color="white" fontSize="sm" fontWeight="medium">
            {currentIndex + 1} / {images.length}
          </Text>
        </Box>
        
        {userRole === "MENTOR" && (
            <Box position="absolute" right={6} pointerEvents="auto">
            </Box>
        )}
      </Flex>
    </Box>
  );
};